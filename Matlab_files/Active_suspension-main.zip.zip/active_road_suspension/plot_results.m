% Extract parallel data from the workspace
accel_stsmc = out.zs_ddot_sim1;
defl_stsmc  = out.susp_defl_sim1;

accel_lqr = out.zs_ddot_sim;
defl_lqr  = out.susp_defl_sim;

% Calculate Peaks (Mechanical limits and maximum shocks)
peak_accel_stsmc = max(abs(accel_stsmc));
peak_accel_lqr   = max(abs(accel_lqr));
peak_defl_stsmc  = max(abs(defl_stsmc));
peak_defl_lqr    = max(abs(defl_lqr));

% Calculate RMS (Sustained vibrational energy and ride comfort)
rms_accel_stsmc = rms(accel_stsmc);
rms_accel_lqr   = rms(accel_lqr);
rms_defl_stsmc  = rms(defl_stsmc);
rms_defl_lqr    = rms(defl_lqr);

% Print the analysis matrix
fprintf('\n=== FINAL PERFORMANCE METRICS ===\n');
fprintf('STSMC Accel | Peak: %7.4f m/s^2 | RMS: %7.4f m/s^2\n', peak_accel_stsmc, rms_accel_stsmc);
fprintf('LQR   Accel | Peak: %7.4f m/s^2 | RMS: %7.4f m/s^2\n', peak_accel_lqr, rms_accel_lqr);
fprintf('------------------------------------------------------\n');
fprintf('STSMC Defl  | Peak: %7.4f m     | RMS: %7.4f m\n', peak_defl_stsmc, rms_defl_stsmc);
fprintf('LQR   Defl  | Peak: %7.4f m     | RMS: %7.4f m\n', peak_defl_lqr, rms_defl_lqr);
fprintf('======================================================\n');

% Generate stacked plots
figure;
subplot(2,1,1);
plot(accel_stsmc, 'b', 'LineWidth', 1.5); hold on;
plot(accel_lqr, 'r', 'LineWidth', 1.5);
title('Ride Comfort: Vertical Acceleration');
ylabel('Accel (m/s^2)');
legend('STSMC (Top Rig)', 'LQR (Bottom Rig)'); grid on;

subplot(2,1,2);
plot(defl_stsmc, 'b', 'LineWidth', 1.5); hold on;
plot(defl_lqr, 'r', 'LineWidth', 1.5);
title('Handling: Suspension Deflection');
ylabel('Deflection (m)'); xlabel('Samples');
legend('STSMC', 'LQR'); grid on;